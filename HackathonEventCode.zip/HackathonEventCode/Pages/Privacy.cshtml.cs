﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HackathonEventCode.Pages
{
    public class PrivacyModel : PageModel
    {
        public void Post()
        {
        }
    }
}